var searchData=
[
  ['actualinterval_251',['actualInterval',['../classNTPClient.html#aafe59edef4ec020afdb1c9fd590e9834',1,'NTPClient']]]
];
