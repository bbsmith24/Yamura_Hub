var searchData=
[
  ['accuracyerror_1',['accuracyError',['../NTPEventTypes_8h.html#ab04a3f38407e6839ce1edc75ae02f152ad7b34aa1ebe2a19c2c7de4844e8b4862',1,'NTPEventTypes.h']]],
  ['actualinterval_2',['actualInterval',['../classNTPClient.html#aafe59edef4ec020afdb1c9fd590e9834',1,'NTPClient']]],
  ['adjustoffset_3',['adjustOffset',['../classNTPClient.html#a46adccfa3280ec52132bb2ceb9499567',1,'NTPClient']]],
  ['advancedexample_2eino_4',['advancedExample.ino',['../advancedExample_8ino.html',1,'']]]
];
