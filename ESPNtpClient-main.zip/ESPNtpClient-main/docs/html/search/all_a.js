var searchData=
[
  ['main_2ecpp_68',['main.cpp',['../main_8cpp.html',1,'']]],
  ['maxdispersionerrors_69',['maxDispersionErrors',['../classNTPClient.html#a7416006fb24cce0f8c96b94fa214af12',1,'NTPClient']]],
  ['maxnumsyncretry_70',['maxNumSyncRetry',['../classNTPClient.html#a47b7d0661fc4c7c036f77e0f8c245bdc',1,'NTPClient']]],
  ['micros_71',['micros',['../classNTPClient.html#a07f05d945cfaf52640446ae9e2acf51a',1,'NTPClient']]],
  ['millis_72',['millis',['../classNTPClient.html#a10a5db32e37a13a7ccc4c7fa0db1ba5f',1,'NTPClient']]],
  ['min_5fntp_5finterval_73',['MIN_NTP_INTERVAL',['../ESPNtpClient_8h.html#ac6b173ed97582fa3df0b764c9fcf1456',1,'ESPNtpClient.h']]],
  ['min_5fntp_5ftimeout_74',['MIN_NTP_TIMEOUT',['../ESPNtpClient_8h.html#a4225ca4c9809b1c8090f94eec14785e4',1,'ESPNtpClient.h']]],
  ['minsyncaccuracyus_75',['minSyncAccuracyUs',['../classNTPClient.html#a366c8c3eb61ba2ada1e8ad8e368e8f26',1,'NTPClient']]],
  ['mode_76',['mode',['../structNTPFlags__t.html#afefa4829c9695778449968eb49877ed6',1,'NTPFlags_t']]]
];
