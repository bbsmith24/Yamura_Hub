var searchData=
[
  ['timedelay_328',['timedelay',['../advancedExample_8ino.html#a8f6e70cd05cccf0eef68d0917400a9b2',1,'timedelay():&#160;advancedExample.ino'],['../main_8cpp.html#a8f6e70cd05cccf0eef68d0917400a9b2',1,'timedelay():&#160;main.cpp']]],
  ['timesyncthreshold_329',['timeSyncThreshold',['../classNTPClient.html#a523c0808e8f02f380966d3f8015893a5',1,'NTPClient']]],
  ['timezone_330',['timeZone',['../classNTPClient.html#aa4c5814d2843bed6b19152bb4ad899d3',1,'NTPClient']]],
  ['transmit_331',['transmit',['../structNTPPacket__t.html#af2da1173fd11f13ec7ac1dc3ef694579',1,'NTPPacket_t']]],
  ['tzname_332',['tzname',['../classNTPClient.html#ac62889ca9614d4428c5ae0046b0b386e',1,'NTPClient']]],
  ['tzname_5flength_333',['TZNAME_LENGTH',['../ESPNtpClient_8h.html#a6686880144c9ae5f8976db520efdc40a',1,'ESPNtpClient.h']]]
];
