var searchData=
[
  ['basicexample_2eino_5',['basicExample.ino',['../basicExample_8ino.html',1,'']]],
  ['begin_6',['begin',['../classNTPClient.html#a4bd1663f4ec21b44ee696c44fc6b7674',1,'NTPClient']]]
];
