var searchData=
[
  ['dbg_5fport_357',['DBG_PORT',['../ESPNtpClient_8cpp.html#adc170618365b3cca7bf58df7cfaa0ffe',1,'ESPNtpClient.cpp']]],
  ['debuglog_358',['DEBUGLOG',['../ESPNtpClient_8cpp.html#ad90d8205f7f73a2e3324ae5aff97e9bc',1,'ESPNtpClient.cpp']]]
];
