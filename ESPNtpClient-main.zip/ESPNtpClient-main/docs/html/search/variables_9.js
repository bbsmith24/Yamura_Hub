var searchData=
[
  ['offset_296',['offset',['../classNTPClient.html#adaa984deb242efe2535554295f37f70d',1,'NTPClient::offset()'],['../structNTPSyncEventInfo__t.html#a60d5072345b2c88a916f84cc41cbefce',1,'NTPSyncEventInfo_t::offset()'],['../advancedExample_8ino.html#a129303e4bd38a8cdba722b6238ed56e9',1,'offset():&#160;advancedExample.ino'],['../main_8cpp.html#a129303e4bd38a8cdba722b6238ed56e9',1,'offset():&#160;main.cpp']]],
  ['offsetave_297',['offsetAve',['../classNTPClient.html#affd7224b47813dd4ab08dd08f2f372d0',1,'NTPClient']]],
  ['offsetsum_298',['offsetSum',['../classNTPClient.html#aa53fad57d17b461dbe9a81177e64207b',1,'NTPClient']]],
  ['onsyncevent_299',['onSyncEvent',['../classNTPClient.html#aea5566858cfcbb1f5f224f4d63e1c3d1',1,'NTPClient']]],
  ['origin_300',['origin',['../structNTPPacket__t.html#a99eaf7f824db8f50f803a0903aadd480',1,'NTPPacket_t']]]
];
