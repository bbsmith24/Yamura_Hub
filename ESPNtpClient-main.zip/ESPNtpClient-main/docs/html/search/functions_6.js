var searchData=
[
  ['getdatestr_210',['getDateStr',['../classNTPClient.html#ac31c226e294a823d26fcc179183539a6',1,'NTPClient::getDateStr()'],['../classNTPClient.html#a0a9194b774644e970ba1ca8cc5472b9f',1,'NTPClient::getDateStr(timeval moment)'],['../classNTPClient.html#a6a07fbfa740320dcfdcafd8cb344128f',1,'NTPClient::getDateStr(time_t moment)']]],
  ['getfirstsync_211',['getFirstSync',['../classNTPClient.html#a804e5322968c52b5b2e48b81e5b49567',1,'NTPClient']]],
  ['getfirstsyncus_212',['getFirstSyncUs',['../classNTPClient.html#a67e8ed036910e2d1b759f6c4bbb26566',1,'NTPClient']]],
  ['getinterval_213',['getInterval',['../classNTPClient.html#aaddfefb13c8de737c63f89d46d5386e5',1,'NTPClient']]],
  ['getlastntpsync_214',['getLastNTPSync',['../classNTPClient.html#a58c7f76a980abb0eae66262f83206960',1,'NTPClient']]],
  ['getlastntpsyncus_215',['getLastNTPSyncUs',['../classNTPClient.html#a69a5f48f5f00cafaea54267bd80d3169',1,'NTPClient']]],
  ['getlonginterval_216',['getLongInterval',['../classNTPClient.html#ab8eca0e89d94ea7fb85e9b87c2be667d',1,'NTPClient']]],
  ['getntpservername_217',['getNtpServerName',['../classNTPClient.html#a036ae4c6db1e446646f6271ea6df6ffc',1,'NTPClient']]],
  ['getshortinterval_218',['getShortInterval',['../classNTPClient.html#aa03b14e52db7517b7af4af6cc9377cb5',1,'NTPClient']]],
  ['gettime_219',['getTime',['../classNTPClient.html#a943007de4fd489ce8a2a0bd6e7f137e4',1,'NTPClient']]],
  ['gettimedatestring_220',['getTimeDateString',['../classNTPClient.html#a09ca5c7c9033d9ed26c3b6abb7e1605f',1,'NTPClient::getTimeDateString()'],['../classNTPClient.html#a2568fa3772d950187188c6de90703eb4',1,'NTPClient::getTimeDateString(timeval moment, const char *format=&quot;%02d/%02m/%04Y %02H:%02M:%02S&quot;)'],['../classNTPClient.html#a46c54a5361fb69ce03e258ac61e88364',1,'NTPClient::getTimeDateString(time_t moment, const char *format=&quot;%02d/%02m/%04Y %02H:%02M:%02S&quot;)']]],
  ['gettimedatestringforjs_221',['getTimeDateStringForJS',['../classNTPClient.html#adb2b4ae34a124f279142cc60a1603b03',1,'NTPClient']]],
  ['gettimedatestringus_222',['getTimeDateStringUs',['../classNTPClient.html#a50afcc3b24639375c620c2bb6366da38',1,'NTPClient']]],
  ['gettimestr_223',['getTimeStr',['../classNTPClient.html#aacf0778cca6caf1af91877e8e4ac18ec',1,'NTPClient::getTimeStr()'],['../classNTPClient.html#ab8970a4e0c6ad06068a5e25421a23d3a',1,'NTPClient::getTimeStr(timeval moment)'],['../classNTPClient.html#add88318f76efecbf79f974979d83498f',1,'NTPClient::getTimeStr(time_t moment)']]],
  ['getuptime_224',['getUptime',['../classNTPClient.html#afd7646fb66c621f58686410b380f8322',1,'NTPClient']]],
  ['getuptimestring_225',['getUptimeString',['../classNTPClient.html#a9e27a96fb803b56bdb314875b354ec94',1,'NTPClient']]]
];
