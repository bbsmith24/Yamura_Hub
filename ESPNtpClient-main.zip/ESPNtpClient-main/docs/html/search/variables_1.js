var searchData=
[
  ['clockprecission_252',['clockPrecission',['../structNTPPacket__t.html#a203d167320b5f457eaad4c5c2287a601',1,'NTPPacket_t']]]
];
