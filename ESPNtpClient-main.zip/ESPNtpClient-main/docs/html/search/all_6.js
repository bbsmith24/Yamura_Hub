var searchData=
[
  ['fast_5fntp_5fsyncnterval_32',['FAST_NTP_SYNCNTERVAL',['../ESPNtpClient_8h.html#a47dfdf92e081ffd69ae4e81378bca43a',1,'ESPNtpClient.h']]],
  ['firstsync_33',['firstSync',['../classNTPClient.html#a1891a4690117bdf8ef47aa07b22ea233',1,'NTPClient']]],
  ['flags_34',['flags',['../structNTPPacket__t.html#a1991b37c1986f94db186e05bae1c39db',1,'NTPPacket_t']]],
  ['flipint16_35',['flipInt16',['../ESPNtpClient_8cpp.html#a13517d74eb9c1f4403c13782bf4c329f',1,'ESPNtpClient.cpp']]],
  ['flipint32_36',['flipInt32',['../ESPNtpClient_8cpp.html#a004437ce9f8976c43a4453a91718a424',1,'ESPNtpClient.cpp']]],
  ['fraction_37',['fraction',['../structtimestamp64__t.html#a917cded3b868aae8b35a8a28e71effcd',1,'timestamp64_t::fraction()'],['../structtimestamp32__t.html#a9d0e20f8db5fa8d60fc05b5db14dfeb6',1,'timestamp32_t::fraction()']]]
];
