var searchData=
[
  ['calculateoffset_7',['calculateOffset',['../classNTPClient.html#af9e2050c75728bd87878f24ba138269c',1,'NTPClient']]],
  ['checkntpresponse_8',['checkNTPresponse',['../classNTPClient.html#a4d2e3c9e4d3a1e3017e824b1afd7bed7',1,'NTPClient']]],
  ['clockprecission_9',['clockPrecission',['../structNTPPacket__t.html#a203d167320b5f457eaad4c5c2287a601',1,'NTPPacket_t']]]
];
