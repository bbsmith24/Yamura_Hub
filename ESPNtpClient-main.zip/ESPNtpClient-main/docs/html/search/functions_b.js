var searchData=
[
  ['processpacket_232',['processPacket',['../classNTPClient.html#a45aa8fb0be0dec2771b76a2c50411e69',1,'NTPClient']]],
  ['processrequesttimeout_233',['processRequestTimeout',['../classNTPClient.html#a55bba0b5a33b16ae6cb4108042e6e8ff',1,'NTPClient']]],
  ['processsyncevent_234',['processSyncEvent',['../advancedExample_8ino.html#a782858657500ca468843899e9c758904',1,'processSyncEvent(NTPEvent_t ntpEvent):&#160;advancedExample.ino'],['../ledFlasher_8ino.html#a782858657500ca468843899e9c758904',1,'processSyncEvent(NTPEvent_t ntpEvent):&#160;ledFlasher.ino'],['../main_8cpp.html#a782858657500ca468843899e9c758904',1,'processSyncEvent(NTPEvent_t ntpEvent):&#160;main.cpp']]]
];
