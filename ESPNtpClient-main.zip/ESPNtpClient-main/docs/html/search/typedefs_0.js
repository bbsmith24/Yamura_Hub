var searchData=
[
  ['ntpstatus_5ft_339',['NTPStatus_t',['../ESPNtpClient_8h.html#a8dd79002fdff254f755a9c4298c190dc',1,'ESPNtpClient.h']]]
];
