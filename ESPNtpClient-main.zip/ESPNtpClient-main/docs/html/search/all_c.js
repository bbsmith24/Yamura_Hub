var searchData=
[
  ['offset_101',['offset',['../classNTPClient.html#adaa984deb242efe2535554295f37f70d',1,'NTPClient::offset()'],['../structNTPSyncEventInfo__t.html#a60d5072345b2c88a916f84cc41cbefce',1,'NTPSyncEventInfo_t::offset()'],['../advancedExample_8ino.html#a129303e4bd38a8cdba722b6238ed56e9',1,'offset():&#160;advancedExample.ino'],['../main_8cpp.html#a129303e4bd38a8cdba722b6238ed56e9',1,'offset():&#160;main.cpp']]],
  ['offsetave_102',['offsetAve',['../classNTPClient.html#affd7224b47813dd4ab08dd08f2f372d0',1,'NTPClient']]],
  ['offsetsum_103',['offsetSum',['../classNTPClient.html#aa53fad57d17b461dbe9a81177e64207b',1,'NTPClient']]],
  ['onboardled_104',['ONBOARDLED',['../advancedExample_8ino.html#aa10709844c6be229a39a26039d1ff3cd',1,'ONBOARDLED():&#160;advancedExample.ino'],['../main_8cpp.html#aa10709844c6be229a39a26039d1ff3cd',1,'ONBOARDLED():&#160;main.cpp']]],
  ['onntpsyncevent_105',['onNTPSyncEvent',['../classNTPClient.html#a7321eb7eab07ccf544f317fac9b6a0e2',1,'NTPClient']]],
  ['onsyncevent_106',['onSyncEvent',['../classNTPClient.html#aea5566858cfcbb1f5f224f4d63e1c3d1',1,'NTPClient']]],
  ['onsyncevent_5ft_107',['onSyncEvent_t',['../ESPNtpClient_8h.html#a25d29b56b51da368f8330f94299b6c32',1,'ESPNtpClient.h']]],
  ['onwifievent_108',['onWifiEvent',['../advancedExample_8ino.html#ad7801276fcdd6c02f1580b3bfee71c1d',1,'onWifiEvent(WiFiEvent_t event):&#160;advancedExample.ino'],['../main_8cpp.html#ad7801276fcdd6c02f1580b3bfee71c1d',1,'onWifiEvent(WiFiEvent_t event):&#160;main.cpp']]],
  ['origin_109',['origin',['../structNTPPacket__t.html#a99eaf7f824db8f50f803a0903aadd480',1,'NTPPacket_t']]]
];
