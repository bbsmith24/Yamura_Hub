var searchData=
[
  ['timestamp32_5ft_188',['timestamp32_t',['../structtimestamp32__t.html',1,'']]],
  ['timestamp64_5ft_189',['timestamp64_t',['../structtimestamp64__t.html',1,'']]]
];
