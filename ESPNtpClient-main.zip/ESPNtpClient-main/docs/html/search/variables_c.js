var searchData=
[
  ['secondsoffset_314',['secondsOffset',['../structtimestamp64__t.html#a121d17a5e997df31f7f9524aa735ed5b',1,'timestamp64_t::secondsOffset()'],['../structtimestamp32__t.html#a0911aacf609221818b3c933fa4e4012e',1,'timestamp32_t::secondsOffset()']]],
  ['secs_5fper_5fday_315',['SECS_PER_DAY',['../ESPNtpClient_8h.html#ae765030e38d5a2c0597925abc040d508',1,'ESPNtpClient.h']]],
  ['secs_5fper_5fhour_316',['SECS_PER_HOUR',['../ESPNtpClient_8h.html#af1d14f09c95ed951cf11be46df73a488',1,'ESPNtpClient.h']]],
  ['secs_5fper_5fmin_317',['SECS_PER_MIN',['../ESPNtpClient_8h.html#adc3cb63600c3b021c0388b50fcb305ef',1,'ESPNtpClient.h']]],
  ['secs_5fper_5fweek_318',['SECS_PER_WEEK',['../ESPNtpClient_8h.html#acd9de23574d29c7cd3043892764ac21d',1,'ESPNtpClient.h']]],
  ['secs_5fper_5fyear_319',['SECS_PER_YEAR',['../ESPNtpClient_8h.html#a39de75627c0098ae816921f13cad47bb',1,'ESPNtpClient.h']]],
  ['secs_5fyr_5f2000_320',['SECS_YR_2000',['../ESPNtpClient_8h.html#ae4761f23a08bea2c2e45be1fd757dbf2',1,'ESPNtpClient.h']]],
  ['server_5fname_5flength_321',['SERVER_NAME_LENGTH',['../ESPNtpClient_8h.html#abf9e5e4e1a2a2fec9eae70c0cb056473',1,'ESPNtpClient.h']]],
  ['serveraddress_322',['serverAddress',['../structNTPSyncEventInfo__t.html#aba3db292c2c80ebe70df204f53884070',1,'NTPSyncEventInfo_t']]],
  ['seventyyears_323',['seventyYears',['../ESPNtpClient_8cpp.html#acd0d9d8dd6599a87d900a8c728421832',1,'ESPNtpClient.cpp']]],
  ['shortinterval_324',['shortInterval',['../classNTPClient.html#a435168f41cd4e698487897454745b2a0',1,'NTPClient']]],
  ['status_325',['status',['../classNTPClient.html#ac6fc7719151efe2da5f7e37748ff4479',1,'NTPClient']]],
  ['strbuffer_326',['strBuffer',['../ESPNtpClient_8h.html#a664853cff9b57a85bd6953ecc4a628e4',1,'ESPNtpClient.h']]],
  ['synceventtriggered_327',['syncEventTriggered',['../advancedExample_8ino.html#a4723d571f64ea64708516f7fd6be1fa8',1,'syncEventTriggered():&#160;advancedExample.ino'],['../ledFlasher_8ino.html#a4723d571f64ea64708516f7fd6be1fa8',1,'syncEventTriggered():&#160;ledFlasher.ino'],['../main_8cpp.html#a4723d571f64ea64708516f7fd6be1fa8',1,'syncEventTriggered():&#160;main.cpp']]]
];
