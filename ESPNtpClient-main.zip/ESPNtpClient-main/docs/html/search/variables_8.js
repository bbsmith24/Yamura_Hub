var searchData=
[
  ['ntp_284',['NTP',['../ESPNtpClient_8cpp.html#a10953f00acc9c54a2371691d10e32a57',1,'NTP():&#160;ESPNtpClient.cpp'],['../ESPNtpClient_8h.html#a10953f00acc9c54a2371691d10e32a57',1,'NTP():&#160;ESPNtpClient.cpp']]],
  ['ntp_5fpacket_5fsize_285',['NTP_PACKET_SIZE',['../ESPNtpClient_8h.html#a79dcb9747083bff5ee2ed05247f5e094',1,'ESPNtpClient.h']]],
  ['ntpevent_286',['ntpEvent',['../advancedExample_8ino.html#afda0e57d1eef1a218a44397c29a88885',1,'ntpEvent():&#160;advancedExample.ino'],['../ledFlasher_8ino.html#afda0e57d1eef1a218a44397c29a88885',1,'ntpEvent():&#160;ledFlasher.ino'],['../main_8cpp.html#afda0e57d1eef1a218a44397c29a88885',1,'ntpEvent():&#160;main.cpp']]],
  ['ntprequested_287',['ntpRequested',['../classNTPClient.html#aa3f352b106fd1c948f850dd141352e5a',1,'NTPClient']]],
  ['ntpserver_288',['ntpServer',['../advancedExample_8ino.html#a752895aa06a97c3166e73ef25b2135ef',1,'ntpServer():&#160;advancedExample.ino'],['../ledFlasher_8ino.html#a752895aa06a97c3166e73ef25b2135ef',1,'ntpServer():&#160;ledFlasher.ino'],['../main_8cpp.html#a752895aa06a97c3166e73ef25b2135ef',1,'ntpServer():&#160;main.cpp']]],
  ['ntpserveripaddress_289',['ntpServerIPAddress',['../classNTPClient.html#ab166bde13addb2bbe840ef41832dc321',1,'NTPClient']]],
  ['ntpservername_290',['ntpServerName',['../classNTPClient.html#a16c1d51a7e29bc38f336f7c54bc9d148',1,'NTPClient']]],
  ['ntptimeout_291',['ntpTimeout',['../classNTPClient.html#a2a29ceecad7c04618e73d41a78674418',1,'NTPClient']]],
  ['ntpundecodedpacket_5ft_292',['NTPUndecodedPacket_t',['../ESPNtpClient_8cpp.html#aaacab2c3d11b1c71ca873492349f57d7',1,'ESPNtpClient.cpp']]],
  ['numaverounds_293',['numAveRounds',['../classNTPClient.html#af235a651b350cb3fc4681dff3fa74e2d',1,'NTPClient']]],
  ['numdispersionerrors_294',['numDispersionErrors',['../classNTPClient.html#a589a97ac9363744f1d17cee6f7cf572c',1,'NTPClient']]],
  ['numsyncretry_295',['numSyncRetry',['../classNTPClient.html#a6511dc00fe7783f8fdbb655c199908aa',1,'NTPClient']]]
];
