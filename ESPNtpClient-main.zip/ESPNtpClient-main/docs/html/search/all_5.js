var searchData=
[
  ['errorsending_28',['errorSending',['../NTPEventTypes_8h.html#ab04a3f38407e6839ce1edc75ae02f152ac06aaa57cac54353be73a9da80d3c5eb',1,'NTPEventTypes.h']]],
  ['espntpclient_2ecpp_29',['ESPNtpClient.cpp',['../ESPNtpClient_8cpp.html',1,'']]],
  ['espntpclient_2eh_30',['ESPNtpClient.h',['../ESPNtpClient_8h.html',1,'']]],
  ['event_31',['event',['../structNTPEvent__t.html#abd1c33f815f3ef2bf1efb51733fbefee',1,'NTPEvent_t']]]
];
