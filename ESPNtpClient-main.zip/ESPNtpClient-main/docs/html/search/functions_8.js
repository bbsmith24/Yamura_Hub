var searchData=
[
  ['micros_227',['micros',['../classNTPClient.html#a07f05d945cfaf52640446ae9e2acf51a',1,'NTPClient']]],
  ['millis_228',['millis',['../classNTPClient.html#a10a5db32e37a13a7ccc4c7fa0db1ba5f',1,'NTPClient']]]
];
