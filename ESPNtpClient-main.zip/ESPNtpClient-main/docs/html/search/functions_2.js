var searchData=
[
  ['begin_202',['begin',['../classNTPClient.html#a4bd1663f4ec21b44ee696c44fc6b7674',1,'NTPClient']]]
];
