var searchData=
[
  ['lastntpresponsepacket_273',['lastNtpResponsePacket',['../classNTPClient.html#ae2bb48a9ab6d1a8dc80618192527dc4b',1,'NTPClient']]],
  ['lastsyncd_274',['lastSyncd',['../classNTPClient.html#acf88f9251f0fc0aa913c07a43c98ebb0',1,'NTPClient']]],
  ['li_275',['li',['../structNTPFlags__t.html#a0beb198b9227ad7dd22b47d5cda1baa9',1,'NTPFlags_t']]],
  ['longinterval_276',['longInterval',['../classNTPClient.html#a4ec812a51fa11876ada81ba7ab24b123',1,'NTPClient']]],
  ['looptimer_277',['loopTimer',['../classNTPClient.html#a317c58e4e14c6c79db2f750f97b6928b',1,'NTPClient']]]
];
